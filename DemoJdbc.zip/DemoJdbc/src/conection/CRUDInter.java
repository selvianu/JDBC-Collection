package conection;

public class CRUDInter {

}
