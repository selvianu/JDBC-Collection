package conection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestConnec {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Connection conn = getConnection();
		System.out.println("Enter actor name and gender");
		Scanner sc = new Scanner(System.in);
		String actorName = sc.next();
		String actorGender = sc.next();
		String query = "INSERT INTO actor(actor_name,gender) VALUES(?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setString(1, actorName);
		ps.setString(2, actorGender);
		int noOfRows = ps.executeUpdate();
		System.out.println(noOfRows + " inserted");
	}

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://13.233.226.80/selvi_db", "selvi", "Nithin@2018");
		// System.out.println(con);
		return con;
	}

}
