package conection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class TestCRUD {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection conn = TestConnec.getConnection();

		CRUDInterfaImpl c = new CRUDInterfaImpl();
		// c.deleteWithId();
		
		/*List<Actor> listOfActors = c.listOfActors();
		System.out.println("List of Actors");
		for (Actor actor : listOfActors) {
			System.out.println(listOfActors);
		}*/
	/*	List<Actor> searchByName = c.searchByName();
		for (Actor actor : searchByName) {
			System.out.println(searchByName);

		}*/

	}

}
