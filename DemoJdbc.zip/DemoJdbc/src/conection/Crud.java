package conection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Crud {
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		Connection conn = TestConnec.getConnection();
		// deleteWithId(conn);
		// deleteWithName(conn);
		// listOfActors(conn);
		List<Actor> list = list(conn);
		for (Actor actor : list) {
			System.out.println(actor);
		}
	}

	public static void deleteWithId(Connection conn) throws SQLException {

	}

	public static void deleteWithName(Connection conn) throws SQLException {
		Actor a = new Actor();
		System.out.println("Enter the actor name that has to be deleted");
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		a.setName(name);// with POJO
		String actorName = a.getName();
		String deleteQuery = "DELETE FROM actor WHERE actor_name=?";
		PreparedStatement ps = conn.prepareStatement(deleteQuery);
		ps.setString(1, actorName);
		int recordsDeleted = ps.executeUpdate();
		System.out.println(recordsDeleted + " no of rows deleted");
	}

	public static void listOfActors(Connection conn) throws SQLException {
		String query = "SELECT * FROM ACTOR";
		PreparedStatement ps1 = conn.prepareStatement(query);
		ResultSet rs = ps1.executeQuery();
		while (rs.next()) {
			System.out.println("Actor Id:  " + rs.getInt(1) + "Actor Name:  " + rs.getString(2)
					+ "Gender of the actor  " + rs.getString(3));
		}

	}

	public static List<Actor> list(Connection conn) throws SQLException {
		String query = "SELECT * FROM ACTOR";
		PreparedStatement ps1 = conn.prepareStatement(query);
		ResultSet rs = ps1.executeQuery();
		List<Actor> actorList = new ArrayList<>();
		while (rs.next()) {
			Actor actor = new Actor();
			actor.setId(rs.getInt(1));
			actor.setName(rs.getString(2));
			actor.setGender(rs.getString(3));
			// System.out.println(actor);
			actorList.add(actor);

		}

		return actorList;
	}

	public List<Actor> searchByName() throws ClassNotFoundException, SQLException {
		Connection conn = TestConnec.getConnection();
		Actor a = new Actor();
		System.out.println("Enter Actor name:  ");
		Scanner s = new Scanner(System.in);
		String actorName = s.next();
		a.setName(actorName);
		String query = "SELECT * FROM ACTOR where actor_name =?";
		PreparedStatement ps1 = conn.prepareStatement(query);
		ps1.setString(1, a.getName());
		ResultSet rs = ps1.executeQuery();
		List<Actor> actorDetails = new ArrayList<>();
		while (rs.next()) {
			Actor actor = new Actor();
			actor.setId(rs.getInt(1));
			// actor.setName(rs.getString(2));
			actor.setGender(rs.getString(3));
			// System.out.println(actor);
			actorDetails.add(actor);
		}
		return actorDetails;
	}
}
