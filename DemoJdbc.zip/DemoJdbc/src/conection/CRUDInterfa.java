package conection;

import java.sql.SQLException;
import java.util.List;

public interface CRUDInterfa {
	public void deleteWithId() throws SQLException, ClassNotFoundException;

	public List<Actor> listOfActors() throws ClassNotFoundException, SQLException;

	public List<Actor> searchByName() throws ClassNotFoundException, SQLException;
}
