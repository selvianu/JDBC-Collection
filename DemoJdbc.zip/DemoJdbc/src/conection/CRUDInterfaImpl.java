package conection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CRUDInterfaImpl implements CRUDInterfa {

	@Override
	public void deleteWithId() throws SQLException, ClassNotFoundException {
		Actor a = new Actor();
		Connection conn = TestConnec.getConnection();
		System.out.println("Enter the actor id that has to be deleted");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		// setters n getters
		a.setId(id);
		int id2 = a.getId();
		String deleteQuery = "DELETE FROM actor WHERE id=?";
		PreparedStatement ps = conn.prepareStatement(deleteQuery);
		ps.setInt(1, id2);
		int recordsDeleted = ps.executeUpdate();
		System.out.println(recordsDeleted + " no of rows deleted");
	}

	@Override
	public List<Actor> listOfActors() throws ClassNotFoundException, SQLException {
		Connection conn = TestConnec.getConnection();
		String query = "SELECT * FROM ACTOR";
		PreparedStatement ps1 = conn.prepareStatement(query);
		ResultSet rs = ps1.executeQuery();
		List<Actor> actorList = new ArrayList<>();
		while (rs.next()) {
			Actor actor = new Actor();
			actor.setId(rs.getInt(1));
			actor.setName(rs.getString(2));
			actor.setGender(rs.getString(3));
			// System.out.println(actor);
			actorList.add(actor);
		}
		return actorList;
	}

	@Override
	public List<Actor> searchByName() throws ClassNotFoundException, SQLException {
		Connection conn = TestConnec.getConnection();
		Actor a = new Actor();
		System.out.println("Enter Actor name:  ");
		Scanner s = new Scanner(System.in);
		String actorName = s.next();
		a.setName(actorName);
		String query = "SELECT * FROM ACTOR where actor_name =?";
		PreparedStatement ps1 = conn.prepareStatement(query);
		ps1.setString(1, a.getName());
		ResultSet rs = ps1.executeQuery();
		List<Actor> actorDetails = new ArrayList<>();
		while (rs.next()) {
			Actor actor = new Actor();
			actor.setId(rs.getInt(1));
			actor.setName(rs.getString(2));
			actor.setGender(rs.getString(3));
			// System.out.println(actor);
			actorDetails.add(actor);
		}
		return actorDetails;

	}

}
